package debruijn;

public interface IPrint {
	String print();
}
