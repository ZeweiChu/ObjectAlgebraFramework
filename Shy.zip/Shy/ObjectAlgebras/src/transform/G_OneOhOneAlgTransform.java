package transform;

import java.util.function.Function;
import java.util.List;
import java.util.ArrayList;
import trees.OneOhOneAlg;

public interface G_OneOhOneAlgTransform<A, B0, B1, B2, B3, B4, B5> extends OneOhOneAlg<Function<A, B0>, Function<A, B1>, Function<A, B2>, Function<A, B3>, Function<A, B4>, Function<A, B5>> {

	OneOhOneAlg<B0, B1, B2, B3, B4, B5> oneOhOneAlg();

	default <B> List<B> substListOneOhOneAlg(List<Function<A, B>> list, A acc) {
		List<B> res = new ArrayList<B>();
		for (Function<A, B> i : list)
			res.add(i.apply(acc));
		return res;
	}

	@Override
	default Function<A, B0> C(List<Function<A, B1>> p0) {
		return acc -> oneOhOneAlg().C(substListOneOhOneAlg(p0, acc));
	}

	@Override
	default Function<A, B1> D(java.lang.String p0, Function<A, B3> p1, List<Function<A, B2>> p2) {
		return acc -> oneOhOneAlg().D(p0, p1.apply(acc), substListOneOhOneAlg(p2, acc));
	}

	@Override
	default Function<A, B2> DU(Function<A, B1> p0) {
		return acc -> oneOhOneAlg().DU(p0.apply(acc));
	}

	@Override
	default Function<A, B3> E(Function<A, B4> p0, Function<A, B5> p1) {
		return acc -> oneOhOneAlg().E(p0.apply(acc), p1.apply(acc));
	}

	@Override
	default Function<A, B4> P(java.lang.String p0, java.lang.String p1) {
		return acc -> oneOhOneAlg().P(p0, p1);
	}

	@Override
	default Function<A, B2> PU(Function<A, B3> p0) {
		return acc -> oneOhOneAlg().PU(p0.apply(acc));
	}

	@Override
	default Function<A, B5> S(float p0) {
		return acc -> oneOhOneAlg().S(p0);
	}

}