package transform;

import trees.StatAlg;

public interface StatAlgTransform<A0, A1> extends StatAlg<A0, A1> {

	StatAlg<A0, A1> statAlg();

	@Override
	default A1 Assign(java.lang.String p0, A0 p1) {
		return statAlg().Assign(p0, p1);
	}

	@Override
	default A1 Seq(A1 p0, A1 p1) {
		return statAlg().Seq(p0, p1);
	}

}