package transform;

import trees.OneOhOneAlg;

public interface OneOhOneAlgTransform<A0, A1, A2, A3, A4, A5> extends OneOhOneAlg<A0, A1, A2, A3, A4, A5> {

	OneOhOneAlg<A0, A1, A2, A3, A4, A5> oneOhOneAlg();

	@Override
	default A0 C(java.util.List<A1> p0) {
		return oneOhOneAlg().C(p0);
	}

	@Override
	default A1 D(java.lang.String p0, A3 p1, java.util.List<A2> p2) {
		return oneOhOneAlg().D(p0, p1, p2);
	}

	@Override
	default A2 DU(A1 p0) {
		return oneOhOneAlg().DU(p0);
	}

	@Override
	default A3 E(A4 p0, A5 p1) {
		return oneOhOneAlg().E(p0, p1);
	}

	@Override
	default A4 P(java.lang.String p0, java.lang.String p1) {
		return oneOhOneAlg().P(p0, p1);
	}

	@Override
	default A2 PU(A3 p0) {
		return oneOhOneAlg().PU(p0);
	}

	@Override
	default A5 S(float p0) {
		return oneOhOneAlg().S(p0);
	}

}