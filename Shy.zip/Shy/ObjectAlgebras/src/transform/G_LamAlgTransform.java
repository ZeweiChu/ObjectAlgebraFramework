package transform;

import java.util.function.Function;
import java.util.List;
import java.util.ArrayList;
import trees.LamAlg;

public interface G_LamAlgTransform<A, B0> extends LamAlg<Function<A, B0>> {

	LamAlg<B0> lamAlg();

	default <B> List<B> substListLamAlg(List<Function<A, B>> list, A acc) {
		List<B> res = new ArrayList<B>();
		for (Function<A, B> i : list)
			res.add(i.apply(acc));
		return res;
	}

	@Override
	default Function<A, B0> Apply(Function<A, B0> p0, Function<A, B0> p1) {
		return acc -> lamAlg().Apply(p0.apply(acc), p1.apply(acc));
	}

	@Override
	default Function<A, B0> Lam(java.lang.String p0, Function<A, B0> p1) {
		return acc -> lamAlg().Lam(p0, p1.apply(acc));
	}

}