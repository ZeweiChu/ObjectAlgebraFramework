package query;

import library.Monoid;
import trees.StmAlg;

public interface G_StmAlgQuery<A0, A1, A2> extends StmAlg<A0, A1, A2> {

	Monoid<A0> mStm();
	Monoid<A1> mExp();
	Monoid<A2> mTyp();

	@Override
	default A1 EAdd(A1 p0, A1 p1) {
		A1 res = mExp().empty();
		res = mExp().join(res, p0);
		res = mExp().join(res, p1);
		return res;
	}

	@Override
	default A1 EInt(int p0) {
		A1 res = mExp().empty();
		return res;
	}

	@Override
	default A1 EStm(A0 p0) {
		A1 res = mExp().empty();
		return res;
	}

	@Override
	default A1 EVar(java.lang.String p0) {
		A1 res = mExp().empty();
		return res;
	}

	@Override
	default A0 SAss(java.lang.String p0, A1 p1) {
		A0 res = mStm().empty();
		return res;
	}

	@Override
	default A0 SBlock(java.util.List<A0> p0) {
		A0 res = mStm().empty();
		res = mStm().join(res, mStm().fold(p0));
		return res;
	}

	@Override
	default A0 SDecl(A2 p0, java.lang.String p1) {
		A0 res = mStm().empty();
		return res;
	}

	@Override
	default A0 SReturn(A1 p0) {
		A0 res = mStm().empty();
		return res;
	}

	@Override
	default A2 TFloat() {
		A2 res = mTyp().empty();
		return res;
	}

	@Override
	default A2 TInt() {
		A2 res = mTyp().empty();
		return res;
	}

}