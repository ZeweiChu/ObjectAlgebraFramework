package query;

import library.Monoid;
import trees.StmAlg;

public interface StmAlgQuery<R> extends StmAlg<R, R, R> {

	Monoid<R> m();

	default R EAdd(R p0, R p1) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		return res;
	}

	default R EInt(int p0) {
		R res = m().empty();
		return res;
	}

	default R EStm(R p0) {
		R res = m().empty();
		res = m().join(res, p0);
		return res;
	}

	default R EVar(java.lang.String p0) {
		R res = m().empty();
		return res;
	}

	default R SAss(java.lang.String p0, R p1) {
		R res = m().empty();
		res = m().join(res, p1);
		return res;
	}

	default R SBlock(java.util.List<R> p0) {
		R res = m().empty();
		res = m().join(res, m().fold(p0));
		return res;
	}

	default R SDecl(R p0, java.lang.String p1) {
		R res = m().empty();
		res = m().join(res, p0);
		return res;
	}

	default R SReturn(R p0) {
		R res = m().empty();
		res = m().join(res, p0);
		return res;
	}

	default R TFloat() {
		R res = m().empty();
		return res;
	}

	default R TInt() {
		R res = m().empty();
		return res;
	}

}