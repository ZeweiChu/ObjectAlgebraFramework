package query;

import library.Monoid;
import trees.OneOhOneAlg;

public interface OneOhOneAlgQuery<R> extends OneOhOneAlg<R, R, R, R, R, R> {

	Monoid<R> m();

	default R C(java.util.List<R> p0) {
		R res = m().empty();
		res = m().join(res, m().fold(p0));
		return res;
	}

	default R D(java.lang.String p0, R p1, java.util.List<R> p2) {
		R res = m().empty();
		res = m().join(res, p1);
		res = m().join(res, m().fold(p2));
		return res;
	}

	default R DU(R p0) {
		R res = m().empty();
		res = m().join(res, p0);
		return res;
	}

	default R E(R p0, R p1) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		return res;
	}

	default R P(java.lang.String p0, java.lang.String p1) {
		R res = m().empty();
		return res;
	}

	default R PU(R p0) {
		R res = m().empty();
		res = m().join(res, p0);
		return res;
	}

	default R S(float p0) {
		R res = m().empty();
		return res;
	}

}