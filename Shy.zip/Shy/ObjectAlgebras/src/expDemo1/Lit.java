package expDemo1;

public interface Lit {

}
