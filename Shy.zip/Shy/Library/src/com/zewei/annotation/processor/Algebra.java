package com.zewei.annotation.processor;

public @interface Algebra {}
