package ql_obj_alg.format;

public interface IPrecedence {
	int prec();
}
