package ql_obj_alg.cycles;

public interface IExpDependency {
	Dependencies dependency(Dependencies currentDependencies);
}
