package ql_obj_alg.check;

public class TypeChecker implements ExprTypeChecker, FormTypeChecker, StmtTypeChecker {

}
