package combinator;

import java.util.ArrayList;
import java.util.List;
import library.Pair;
import ql_obj_alg.syntax.IUnlessAlg;

public class CombineIUnlessAlg<A0, A1, B0, B1>
	implements IUnlessAlg<Pair<A0, B0>, Pair<A1, B1>> {

	public IUnlessAlg<A0, A1> alg1;
	public IUnlessAlg<B0, B1> alg2;

	public CombineIUnlessAlg(IUnlessAlg<A0, A1> _alg1, IUnlessAlg<B0, B1> _alg2) {
		alg1 = _alg1;
		alg2 = _alg2;
	}

	private <A, B> Pair<List<A>, List<B>> getPairList(List<Pair<A, B>> l) {
		List<A> l1 = (List<A>)new ArrayList<A>();
		List<B> l2 = (List<B>)new ArrayList<B>();
		for (Pair<A, B> element : l) {
			l1.add(element.a());
			l2.add(element.b());
		}
		return new Pair<List<A>, List<B>>(l1, l2);
	}

	public Pair<A1, B1> unless(Pair<A0, B0> p0, Pair<A1, B1> p1) {
		return new Pair<A1, B1>(alg1.unless(p0.a(), p1.a()), alg2.unless(p0.b(), p1.b()));
	}

}