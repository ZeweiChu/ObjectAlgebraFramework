package combinator;

import java.util.ArrayList;
import java.util.List;
import library.Pair;
import ql_obj_alg.syntax.IFormAlg;

public class CombineIFormAlg<A0, A1, A2, B0, B1, B2>
	implements IFormAlg<Pair<A0, B0>, Pair<A1, B1>, Pair<A2, B2>> {

	public IFormAlg<A0, A1, A2> alg1;
	public IFormAlg<B0, B1, B2> alg2;

	public CombineIFormAlg(IFormAlg<A0, A1, A2> _alg1, IFormAlg<B0, B1, B2> _alg2) {
		alg1 = _alg1;
		alg2 = _alg2;
	}

	private <A, B> Pair<List<A>, List<B>> getPairList(List<Pair<A, B>> l) {
		List<A> l1 = (List<A>)new ArrayList<A>();
		List<B> l2 = (List<B>)new ArrayList<B>();
		for (Pair<A, B> element : l) {
			l1.add(element.a());
			l2.add(element.b());
		}
		return new Pair<List<A>, List<B>>(l1, l2);
	}

	public Pair<A2, B2> form(java.lang.String p0, List<Pair<A1, B1>> p1) {
		return new Pair<A2, B2>(alg1.form(p0, getPairList(p1).a()), alg2.form(p0, getPairList(p1).b()));
	}

}