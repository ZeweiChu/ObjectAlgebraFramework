package combinator;

import java.util.ArrayList;
import java.util.List;
import library.Pair;
import ql_obj_alg.syntax.IStmtAlg;

public class CombineIStmtAlg<A0, A1, B0, B1>
	implements IStmtAlg<Pair<A0, B0>, Pair<A1, B1>> {

	public IStmtAlg<A0, A1> alg1;
	public IStmtAlg<B0, B1> alg2;

	public CombineIStmtAlg(IStmtAlg<A0, A1> _alg1, IStmtAlg<B0, B1> _alg2) {
		alg1 = _alg1;
		alg2 = _alg2;
	}

	private <A, B> Pair<List<A>, List<B>> getPairList(List<Pair<A, B>> l) {
		List<A> l1 = (List<A>)new ArrayList<A>();
		List<B> l2 = (List<B>)new ArrayList<B>();
		for (Pair<A, B> element : l) {
			l1.add(element.a());
			l2.add(element.b());
		}
		return new Pair<List<A>, List<B>>(l1, l2);
	}

	public Pair<A1, B1> block(List<Pair<A1, B1>> p0) {
		return new Pair<A1, B1>(alg1.block(getPairList(p0).a()), alg2.block(getPairList(p0).b()));
	}

	public Pair<A1, B1> iff(Pair<A0, B0> p0, Pair<A1, B1> p1) {
		return new Pair<A1, B1>(alg1.iff(p0.a(), p1.a()), alg2.iff(p0.b(), p1.b()));
	}

	public Pair<A1, B1> iffelse(Pair<A0, B0> p0, Pair<A1, B1> p1, Pair<A1, B1> p2) {
		return new Pair<A1, B1>(alg1.iffelse(p0.a(), p1.a(), p2.a()), alg2.iffelse(p0.b(), p1.b(), p2.b()));
	}

	public Pair<A1, B1> question(java.lang.String p0, java.lang.String p1, ql_obj_alg.check.types.Type p2) {
		return new Pair<A1, B1>(alg1.question(p0, p1, p2), alg2.question(p0, p1, p2));
	}

	public Pair<A1, B1> question(java.lang.String p0, java.lang.String p1, ql_obj_alg.check.types.Type p2, Pair<A0, B0> p3) {
		return new Pair<A1, B1>(alg1.question(p0, p1, p2, p3.a()), alg2.question(p0, p1, p2, p3.b()));
	}

}