package combinator;

import java.util.ArrayList;
import java.util.List;
import library.Pair;
import ql_obj_alg.syntax.IExpAlg;

public class CombineIExpAlg<A0, B0>
	implements IExpAlg<Pair<A0, B0>> {

	public IExpAlg<A0> alg1;
	public IExpAlg<B0> alg2;

	public CombineIExpAlg(IExpAlg<A0> _alg1, IExpAlg<B0> _alg2) {
		alg1 = _alg1;
		alg2 = _alg2;
	}

	private <A, B> Pair<List<A>, List<B>> getPairList(List<Pair<A, B>> l) {
		List<A> l1 = (List<A>)new ArrayList<A>();
		List<B> l2 = (List<B>)new ArrayList<B>();
		for (Pair<A, B> element : l) {
			l1.add(element.a());
			l2.add(element.b());
		}
		return new Pair<List<A>, List<B>>(l1, l2);
	}

	public Pair<A0, B0> add(Pair<A0, B0> p0, Pair<A0, B0> p1) {
		return new Pair<A0, B0>(alg1.add(p0.a(), p1.a()), alg2.add(p0.b(), p1.b()));
	}

	public Pair<A0, B0> and(Pair<A0, B0> p0, Pair<A0, B0> p1) {
		return new Pair<A0, B0>(alg1.and(p0.a(), p1.a()), alg2.and(p0.b(), p1.b()));
	}

	public Pair<A0, B0> bool(boolean p0) {
		return new Pair<A0, B0>(alg1.bool(p0), alg2.bool(p0));
	}

	public Pair<A0, B0> bracket(Pair<A0, B0> p0) {
		return new Pair<A0, B0>(alg1.bracket(p0.a()), alg2.bracket(p0.b()));
	}

	public Pair<A0, B0> div(Pair<A0, B0> p0, Pair<A0, B0> p1) {
		return new Pair<A0, B0>(alg1.div(p0.a(), p1.a()), alg2.div(p0.b(), p1.b()));
	}

	public Pair<A0, B0> eq(Pair<A0, B0> p0, Pair<A0, B0> p1) {
		return new Pair<A0, B0>(alg1.eq(p0.a(), p1.a()), alg2.eq(p0.b(), p1.b()));
	}

	public Pair<A0, B0> geq(Pair<A0, B0> p0, Pair<A0, B0> p1) {
		return new Pair<A0, B0>(alg1.geq(p0.a(), p1.a()), alg2.geq(p0.b(), p1.b()));
	}

	public Pair<A0, B0> gt(Pair<A0, B0> p0, Pair<A0, B0> p1) {
		return new Pair<A0, B0>(alg1.gt(p0.a(), p1.a()), alg2.gt(p0.b(), p1.b()));
	}

	public Pair<A0, B0> leq(Pair<A0, B0> p0, Pair<A0, B0> p1) {
		return new Pair<A0, B0>(alg1.leq(p0.a(), p1.a()), alg2.leq(p0.b(), p1.b()));
	}

	public Pair<A0, B0> lit(int p0) {
		return new Pair<A0, B0>(alg1.lit(p0), alg2.lit(p0));
	}

	public Pair<A0, B0> lt(Pair<A0, B0> p0, Pair<A0, B0> p1) {
		return new Pair<A0, B0>(alg1.lt(p0.a(), p1.a()), alg2.lt(p0.b(), p1.b()));
	}

	public Pair<A0, B0> mul(Pair<A0, B0> p0, Pair<A0, B0> p1) {
		return new Pair<A0, B0>(alg1.mul(p0.a(), p1.a()), alg2.mul(p0.b(), p1.b()));
	}

	public Pair<A0, B0> neq(Pair<A0, B0> p0, Pair<A0, B0> p1) {
		return new Pair<A0, B0>(alg1.neq(p0.a(), p1.a()), alg2.neq(p0.b(), p1.b()));
	}

	public Pair<A0, B0> not(Pair<A0, B0> p0) {
		return new Pair<A0, B0>(alg1.not(p0.a()), alg2.not(p0.b()));
	}

	public Pair<A0, B0> or(Pair<A0, B0> p0, Pair<A0, B0> p1) {
		return new Pair<A0, B0>(alg1.or(p0.a(), p1.a()), alg2.or(p0.b(), p1.b()));
	}

	public Pair<A0, B0> string(java.lang.String p0) {
		return new Pair<A0, B0>(alg1.string(p0), alg2.string(p0));
	}

	public Pair<A0, B0> sub(Pair<A0, B0> p0, Pair<A0, B0> p1) {
		return new Pair<A0, B0>(alg1.sub(p0.a(), p1.a()), alg2.sub(p0.b(), p1.b()));
	}

	public Pair<A0, B0> var(java.lang.String p0) {
		return new Pair<A0, B0>(alg1.var(p0), alg2.var(p0));
	}

}