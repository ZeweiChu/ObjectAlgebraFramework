package transform;

import java.util.function.Function;
import java.util.List;
import java.util.ArrayList;
import ql_obj_alg.syntax.IExpAlg;

public interface G_IExpAlgTransform<A, B0> extends IExpAlg<Function<A, B0>> {

	IExpAlg<B0> iExpAlg();

	default <B> List<B> substListIExpAlg(List<Function<A, B>> list, A acc) {
		List<B> res = new ArrayList<B>();
		for (Function<A, B> i : list)
			res.add(i.apply(acc));
		return res;
	}

	@Override
	default Function<A, B0> add(Function<A, B0> p0, Function<A, B0> p1) {
		return acc -> iExpAlg().add(p0.apply(acc), p1.apply(acc));
	}

	@Override
	default Function<A, B0> and(Function<A, B0> p0, Function<A, B0> p1) {
		return acc -> iExpAlg().and(p0.apply(acc), p1.apply(acc));
	}

	@Override
	default Function<A, B0> bool(boolean p0) {
		return acc -> iExpAlg().bool(p0);
	}

	@Override
	default Function<A, B0> bracket(Function<A, B0> p0) {
		return acc -> iExpAlg().bracket(p0.apply(acc));
	}

	@Override
	default Function<A, B0> div(Function<A, B0> p0, Function<A, B0> p1) {
		return acc -> iExpAlg().div(p0.apply(acc), p1.apply(acc));
	}

	@Override
	default Function<A, B0> eq(Function<A, B0> p0, Function<A, B0> p1) {
		return acc -> iExpAlg().eq(p0.apply(acc), p1.apply(acc));
	}

	@Override
	default Function<A, B0> geq(Function<A, B0> p0, Function<A, B0> p1) {
		return acc -> iExpAlg().geq(p0.apply(acc), p1.apply(acc));
	}

	@Override
	default Function<A, B0> gt(Function<A, B0> p0, Function<A, B0> p1) {
		return acc -> iExpAlg().gt(p0.apply(acc), p1.apply(acc));
	}

	@Override
	default Function<A, B0> leq(Function<A, B0> p0, Function<A, B0> p1) {
		return acc -> iExpAlg().leq(p0.apply(acc), p1.apply(acc));
	}

	@Override
	default Function<A, B0> lit(int p0) {
		return acc -> iExpAlg().lit(p0);
	}

	@Override
	default Function<A, B0> lt(Function<A, B0> p0, Function<A, B0> p1) {
		return acc -> iExpAlg().lt(p0.apply(acc), p1.apply(acc));
	}

	@Override
	default Function<A, B0> mul(Function<A, B0> p0, Function<A, B0> p1) {
		return acc -> iExpAlg().mul(p0.apply(acc), p1.apply(acc));
	}

	@Override
	default Function<A, B0> neq(Function<A, B0> p0, Function<A, B0> p1) {
		return acc -> iExpAlg().neq(p0.apply(acc), p1.apply(acc));
	}

	@Override
	default Function<A, B0> not(Function<A, B0> p0) {
		return acc -> iExpAlg().not(p0.apply(acc));
	}

	@Override
	default Function<A, B0> or(Function<A, B0> p0, Function<A, B0> p1) {
		return acc -> iExpAlg().or(p0.apply(acc), p1.apply(acc));
	}

	@Override
	default Function<A, B0> string(java.lang.String p0) {
		return acc -> iExpAlg().string(p0);
	}

	@Override
	default Function<A, B0> sub(Function<A, B0> p0, Function<A, B0> p1) {
		return acc -> iExpAlg().sub(p0.apply(acc), p1.apply(acc));
	}

	@Override
	default Function<A, B0> var(java.lang.String p0) {
		return acc -> iExpAlg().var(p0);
	}

}