package transform;

import ql_obj_alg.syntax.IRepeatAlg;

public interface IRepeatAlgTransform<A0> extends IRepeatAlg<A0> {

	IRepeatAlg<A0> iRepeatAlg();

	@Override
	default A0 repeat(int p0, A0 p1) {
		return iRepeatAlg().repeat(p0, p1);
	}

}