package transform;

import java.util.function.Function;
import java.util.List;
import java.util.ArrayList;
import ql_obj_alg.syntax.IRepeatAlg;

public interface G_IRepeatAlgTransform<A, B0> extends IRepeatAlg<Function<A, B0>> {

	IRepeatAlg<B0> iRepeatAlg();

	default <B> List<B> substListIRepeatAlg(List<Function<A, B>> list, A acc) {
		List<B> res = new ArrayList<B>();
		for (Function<A, B> i : list)
			res.add(i.apply(acc));
		return res;
	}

	@Override
	default Function<A, B0> repeat(int p0, Function<A, B0> p1) {
		return acc -> iRepeatAlg().repeat(p0, p1.apply(acc));
	}

}