package transform;

import java.util.function.Function;
import java.util.List;
import java.util.ArrayList;
import ql_obj_alg.syntax.IFormAlg;

public interface G_IFormAlgTransform<A, B0, B1, B2> extends IFormAlg<Function<A, B0>, Function<A, B1>, Function<A, B2>> {

	IFormAlg<B0, B1, B2> iFormAlg();

	default <B> List<B> substListIFormAlg(List<Function<A, B>> list, A acc) {
		List<B> res = new ArrayList<B>();
		for (Function<A, B> i : list)
			res.add(i.apply(acc));
		return res;
	}

	@Override
	default Function<A, B2> form(java.lang.String p0, List<Function<A, B1>> p1) {
		return acc -> iFormAlg().form(p0, substListIFormAlg(p1, acc));
	}

}