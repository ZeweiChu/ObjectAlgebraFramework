package transform;

import ql_obj_alg.syntax.IStmtAlg;

public interface IStmtAlgTransform<A0, A1> extends IStmtAlg<A0, A1> {

	IStmtAlg<A0, A1> iStmtAlg();

	@Override
	default A1 block(java.util.List<A1> p0) {
		return iStmtAlg().block(p0);
	}

	@Override
	default A1 iff(A0 p0, A1 p1) {
		return iStmtAlg().iff(p0, p1);
	}

	@Override
	default A1 iffelse(A0 p0, A1 p1, A1 p2) {
		return iStmtAlg().iffelse(p0, p1, p2);
	}

	@Override
	default A1 question(java.lang.String p0, java.lang.String p1, ql_obj_alg.check.types.Type p2) {
		return iStmtAlg().question(p0, p1, p2);
	}

	@Override
	default A1 question(java.lang.String p0, java.lang.String p1, ql_obj_alg.check.types.Type p2, A0 p3) {
		return iStmtAlg().question(p0, p1, p2, p3);
	}

}