package transform;

import java.util.function.Function;
import java.util.List;
import java.util.ArrayList;
import ql_obj_alg.syntax.IUnlessAlg;

public interface G_IUnlessAlgTransform<A, B0, B1> extends IUnlessAlg<Function<A, B0>, Function<A, B1>> {

	IUnlessAlg<B0, B1> iUnlessAlg();

	default <B> List<B> substListIUnlessAlg(List<Function<A, B>> list, A acc) {
		List<B> res = new ArrayList<B>();
		for (Function<A, B> i : list)
			res.add(i.apply(acc));
		return res;
	}

	@Override
	default Function<A, B1> unless(Function<A, B0> p0, Function<A, B1> p1) {
		return acc -> iUnlessAlg().unless(p0.apply(acc), p1.apply(acc));
	}

}