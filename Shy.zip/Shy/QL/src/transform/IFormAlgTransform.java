package transform;

import ql_obj_alg.syntax.IFormAlg;

public interface IFormAlgTransform<A0, A1, A2> extends IFormAlg<A0, A1, A2> {

	IFormAlg<A0, A1, A2> iFormAlg();

	@Override
	default A2 form(java.lang.String p0, java.util.List<A1> p1) {
		return iFormAlg().form(p0, p1);
	}

}