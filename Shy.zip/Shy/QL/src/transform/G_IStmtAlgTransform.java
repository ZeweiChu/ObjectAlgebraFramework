package transform;

import java.util.function.Function;
import java.util.List;
import java.util.ArrayList;
import ql_obj_alg.syntax.IStmtAlg;

public interface G_IStmtAlgTransform<A, B0, B1> extends IStmtAlg<Function<A, B0>, Function<A, B1>> {

	IStmtAlg<B0, B1> iStmtAlg();

	default <B> List<B> substListIStmtAlg(List<Function<A, B>> list, A acc) {
		List<B> res = new ArrayList<B>();
		for (Function<A, B> i : list)
			res.add(i.apply(acc));
		return res;
	}

	@Override
	default Function<A, B1> block(List<Function<A, B1>> p0) {
		return acc -> iStmtAlg().block(substListIStmtAlg(p0, acc));
	}

	@Override
	default Function<A, B1> iff(Function<A, B0> p0, Function<A, B1> p1) {
		return acc -> iStmtAlg().iff(p0.apply(acc), p1.apply(acc));
	}

	@Override
	default Function<A, B1> iffelse(Function<A, B0> p0, Function<A, B1> p1, Function<A, B1> p2) {
		return acc -> iStmtAlg().iffelse(p0.apply(acc), p1.apply(acc), p2.apply(acc));
	}

	@Override
	default Function<A, B1> question(java.lang.String p0, java.lang.String p1, ql_obj_alg.check.types.Type p2) {
		return acc -> iStmtAlg().question(p0, p1, p2);
	}

	@Override
	default Function<A, B1> question(java.lang.String p0, java.lang.String p1, ql_obj_alg.check.types.Type p2, Function<A, B0> p3) {
		return acc -> iStmtAlg().question(p0, p1, p2, p3.apply(acc));
	}

}