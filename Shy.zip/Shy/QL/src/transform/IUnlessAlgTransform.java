package transform;

import ql_obj_alg.syntax.IUnlessAlg;

public interface IUnlessAlgTransform<A0, A1> extends IUnlessAlg<A0, A1> {

	IUnlessAlg<A0, A1> iUnlessAlg();

	@Override
	default A1 unless(A0 p0, A1 p1) {
		return iUnlessAlg().unless(p0, p1);
	}

}