package transform;

import ql_obj_alg.syntax.IExpAlg;

public interface IExpAlgTransform<A0> extends IExpAlg<A0> {

	IExpAlg<A0> iExpAlg();

	@Override
	default A0 add(A0 p0, A0 p1) {
		return iExpAlg().add(p0, p1);
	}

	@Override
	default A0 and(A0 p0, A0 p1) {
		return iExpAlg().and(p0, p1);
	}

	@Override
	default A0 bool(boolean p0) {
		return iExpAlg().bool(p0);
	}

	@Override
	default A0 bracket(A0 p0) {
		return iExpAlg().bracket(p0);
	}

	@Override
	default A0 div(A0 p0, A0 p1) {
		return iExpAlg().div(p0, p1);
	}

	@Override
	default A0 eq(A0 p0, A0 p1) {
		return iExpAlg().eq(p0, p1);
	}

	@Override
	default A0 geq(A0 p0, A0 p1) {
		return iExpAlg().geq(p0, p1);
	}

	@Override
	default A0 gt(A0 p0, A0 p1) {
		return iExpAlg().gt(p0, p1);
	}

	@Override
	default A0 leq(A0 p0, A0 p1) {
		return iExpAlg().leq(p0, p1);
	}

	@Override
	default A0 lit(int p0) {
		return iExpAlg().lit(p0);
	}

	@Override
	default A0 lt(A0 p0, A0 p1) {
		return iExpAlg().lt(p0, p1);
	}

	@Override
	default A0 mul(A0 p0, A0 p1) {
		return iExpAlg().mul(p0, p1);
	}

	@Override
	default A0 neq(A0 p0, A0 p1) {
		return iExpAlg().neq(p0, p1);
	}

	@Override
	default A0 not(A0 p0) {
		return iExpAlg().not(p0);
	}

	@Override
	default A0 or(A0 p0, A0 p1) {
		return iExpAlg().or(p0, p1);
	}

	@Override
	default A0 string(java.lang.String p0) {
		return iExpAlg().string(p0);
	}

	@Override
	default A0 sub(A0 p0, A0 p1) {
		return iExpAlg().sub(p0, p1);
	}

	@Override
	default A0 var(java.lang.String p0) {
		return iExpAlg().var(p0);
	}

}