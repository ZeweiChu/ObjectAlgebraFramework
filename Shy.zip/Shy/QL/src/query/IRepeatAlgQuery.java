package query;

import library.Monoid;
import ql_obj_alg.syntax.IRepeatAlg;

public interface IRepeatAlgQuery<R> extends IRepeatAlg<R> {

	Monoid<R> m();

	default R repeat(int p0, R p1) {
		R res = m().empty();
		res = m().join(res, p1);
		return res;
	}

}