package query;

import library.Monoid;
import ql_obj_alg.syntax.IRepeatAlg;

public interface G_IRepeatAlgQuery<A0> extends IRepeatAlg<A0> {

	Monoid<A0> mS();

	@Override
	default A0 repeat(int p0, A0 p1) {
		A0 res = mS().empty();
		res = mS().join(res, p1);
		return res;
	}

}