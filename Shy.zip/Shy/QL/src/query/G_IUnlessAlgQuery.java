package query;

import library.Monoid;
import ql_obj_alg.syntax.IUnlessAlg;

public interface G_IUnlessAlgQuery<A0, A1> extends IUnlessAlg<A0, A1> {

	Monoid<A0> mE();
	Monoid<A1> mS();

	@Override
	default A1 unless(A0 p0, A1 p1) {
		A1 res = mS().empty();
		res = mS().join(res, p1);
		return res;
	}

}