package query;

import library.Monoid;
import ql_obj_alg.syntax.IFormAlg;

public interface G_IFormAlgQuery<A0, A1, A2> extends IFormAlg<A0, A1, A2> {

	Monoid<A0> mE();
	Monoid<A1> mS();
	Monoid<A2> mF();

	@Override
	default A2 form(java.lang.String p0, java.util.List<A1> p1) {
		A2 res = mF().empty();
		return res;
	}

}