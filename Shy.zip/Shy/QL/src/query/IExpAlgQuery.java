package query;

import library.Monoid;
import ql_obj_alg.syntax.IExpAlg;

public interface IExpAlgQuery<R> extends IExpAlg<R> {

	Monoid<R> m();

	default R add(R p0, R p1) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		return res;
	}

	default R and(R p0, R p1) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		return res;
	}

	default R bool(boolean p0) {
		R res = m().empty();
		return res;
	}

	default R bracket(R p0) {
		R res = m().empty();
		res = m().join(res, p0);
		return res;
	}

	default R div(R p0, R p1) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		return res;
	}

	default R eq(R p0, R p1) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		return res;
	}

	default R geq(R p0, R p1) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		return res;
	}

	default R gt(R p0, R p1) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		return res;
	}

	default R leq(R p0, R p1) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		return res;
	}

	default R lit(int p0) {
		R res = m().empty();
		return res;
	}

	default R lt(R p0, R p1) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		return res;
	}

	default R mul(R p0, R p1) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		return res;
	}

	default R neq(R p0, R p1) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		return res;
	}

	default R not(R p0) {
		R res = m().empty();
		res = m().join(res, p0);
		return res;
	}

	default R or(R p0, R p1) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		return res;
	}

	default R string(java.lang.String p0) {
		R res = m().empty();
		return res;
	}

	default R sub(R p0, R p1) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		return res;
	}

	default R var(java.lang.String p0) {
		R res = m().empty();
		return res;
	}

}