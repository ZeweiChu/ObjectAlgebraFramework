package query;

import library.Monoid;
import ql_obj_alg.syntax.IExpAlg;

public interface G_IExpAlgQuery<A0> extends IExpAlg<A0> {

	Monoid<A0> mE();

	@Override
	default A0 add(A0 p0, A0 p1) {
		A0 res = mE().empty();
		res = mE().join(res, p0);
		res = mE().join(res, p1);
		return res;
	}

	@Override
	default A0 and(A0 p0, A0 p1) {
		A0 res = mE().empty();
		res = mE().join(res, p0);
		res = mE().join(res, p1);
		return res;
	}

	@Override
	default A0 bool(boolean p0) {
		A0 res = mE().empty();
		return res;
	}

	@Override
	default A0 bracket(A0 p0) {
		A0 res = mE().empty();
		res = mE().join(res, p0);
		return res;
	}

	@Override
	default A0 div(A0 p0, A0 p1) {
		A0 res = mE().empty();
		res = mE().join(res, p0);
		res = mE().join(res, p1);
		return res;
	}

	@Override
	default A0 eq(A0 p0, A0 p1) {
		A0 res = mE().empty();
		res = mE().join(res, p0);
		res = mE().join(res, p1);
		return res;
	}

	@Override
	default A0 geq(A0 p0, A0 p1) {
		A0 res = mE().empty();
		res = mE().join(res, p0);
		res = mE().join(res, p1);
		return res;
	}

	@Override
	default A0 gt(A0 p0, A0 p1) {
		A0 res = mE().empty();
		res = mE().join(res, p0);
		res = mE().join(res, p1);
		return res;
	}

	@Override
	default A0 leq(A0 p0, A0 p1) {
		A0 res = mE().empty();
		res = mE().join(res, p0);
		res = mE().join(res, p1);
		return res;
	}

	@Override
	default A0 lit(int p0) {
		A0 res = mE().empty();
		return res;
	}

	@Override
	default A0 lt(A0 p0, A0 p1) {
		A0 res = mE().empty();
		res = mE().join(res, p0);
		res = mE().join(res, p1);
		return res;
	}

	@Override
	default A0 mul(A0 p0, A0 p1) {
		A0 res = mE().empty();
		res = mE().join(res, p0);
		res = mE().join(res, p1);
		return res;
	}

	@Override
	default A0 neq(A0 p0, A0 p1) {
		A0 res = mE().empty();
		res = mE().join(res, p0);
		res = mE().join(res, p1);
		return res;
	}

	@Override
	default A0 not(A0 p0) {
		A0 res = mE().empty();
		res = mE().join(res, p0);
		return res;
	}

	@Override
	default A0 or(A0 p0, A0 p1) {
		A0 res = mE().empty();
		res = mE().join(res, p0);
		res = mE().join(res, p1);
		return res;
	}

	@Override
	default A0 string(java.lang.String p0) {
		A0 res = mE().empty();
		return res;
	}

	@Override
	default A0 sub(A0 p0, A0 p1) {
		A0 res = mE().empty();
		res = mE().join(res, p0);
		res = mE().join(res, p1);
		return res;
	}

	@Override
	default A0 var(java.lang.String p0) {
		A0 res = mE().empty();
		return res;
	}

}