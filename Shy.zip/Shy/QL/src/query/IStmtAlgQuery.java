package query;

import library.Monoid;
import ql_obj_alg.syntax.IStmtAlg;

public interface IStmtAlgQuery<R> extends IStmtAlg<R, R> {

	Monoid<R> m();

	default R block(java.util.List<R> p0) {
		R res = m().empty();
		res = m().join(res, m().fold(p0));
		return res;
	}

	default R iff(R p0, R p1) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		return res;
	}

	default R iffelse(R p0, R p1, R p2) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		res = m().join(res, p2);
		return res;
	}

	default R question(java.lang.String p0, java.lang.String p1, ql_obj_alg.check.types.Type p2) {
		R res = m().empty();
		return res;
	}

	default R question(java.lang.String p0, java.lang.String p1, ql_obj_alg.check.types.Type p2, R p3) {
		R res = m().empty();
		res = m().join(res, p3);
		return res;
	}

}