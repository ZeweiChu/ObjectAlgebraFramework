package query;

import library.Monoid;
import ql_obj_alg.syntax.IFormAlg;

public interface IFormAlgQuery<R> extends IFormAlg<R, R, R> {

	Monoid<R> m();

	default R form(java.lang.String p0, java.util.List<R> p1) {
		R res = m().empty();
		res = m().join(res, m().fold(p1));
		return res;
	}

}