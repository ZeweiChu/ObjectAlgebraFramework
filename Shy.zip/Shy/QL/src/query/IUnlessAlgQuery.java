package query;

import library.Monoid;
import ql_obj_alg.syntax.IUnlessAlg;

public interface IUnlessAlgQuery<R> extends IUnlessAlg<R, R> {

	Monoid<R> m();

	default R unless(R p0, R p1) {
		R res = m().empty();
		res = m().join(res, p0);
		res = m().join(res, p1);
		return res;
	}

}