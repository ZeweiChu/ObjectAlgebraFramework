package query;

import library.Monoid;
import ql_obj_alg.syntax.IStmtAlg;

public interface G_IStmtAlgQuery<A0, A1> extends IStmtAlg<A0, A1> {

	Monoid<A0> mE();
	Monoid<A1> mS();

	@Override
	default A1 block(java.util.List<A1> p0) {
		A1 res = mS().empty();
		res = mS().join(res, mS().fold(p0));
		return res;
	}

	@Override
	default A1 iff(A0 p0, A1 p1) {
		A1 res = mS().empty();
		res = mS().join(res, p1);
		return res;
	}

	@Override
	default A1 iffelse(A0 p0, A1 p1, A1 p2) {
		A1 res = mS().empty();
		res = mS().join(res, p1);
		res = mS().join(res, p2);
		return res;
	}

	@Override
	default A1 question(java.lang.String p0, java.lang.String p1, ql_obj_alg.check.types.Type p2) {
		A1 res = mS().empty();
		return res;
	}

	@Override
	default A1 question(java.lang.String p0, java.lang.String p1, ql_obj_alg.check.types.Type p2, A0 p3) {
		A1 res = mS().empty();
		return res;
	}

}