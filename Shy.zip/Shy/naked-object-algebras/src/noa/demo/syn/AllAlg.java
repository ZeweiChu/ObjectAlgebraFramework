package noa.demo.syn;

import noa.demo.alg.ExpAlg0;
import noa.demo.alg.ProgAlg;

public interface AllAlg<P, E> extends ProgAlg<P, E>, ExpAlg0<E> { 
}

