package ql_obj_alg.check;


public interface ITypeCheck {
	void check(TypeEnvironment typeEnv,ErrorReporting report);
}
