package ql_obj_alg.check;


public interface ICollect {
	void collect(TypeEnvironment typeEnv, ErrorReporting report);
}
