package ql_obj_alg.cycles;

public interface IDependencyGraph {
	void fill(DependencyGraph dependencyGraph, Dependencies currentDependencies);
}
