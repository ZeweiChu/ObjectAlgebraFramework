package ql_obj_alg.cycles;

import ql_obj_alg.check.ErrorReporting;

public interface IDetectCycle {
	void detect(ErrorReporting report);
}
