
cloc.pl `cat _ast_files`
cloc.pl `cat _syb_files`
