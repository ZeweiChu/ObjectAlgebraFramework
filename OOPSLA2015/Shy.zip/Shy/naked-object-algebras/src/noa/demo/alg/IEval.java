package noa.demo.alg;

public interface IEval {
	int eval();
}
