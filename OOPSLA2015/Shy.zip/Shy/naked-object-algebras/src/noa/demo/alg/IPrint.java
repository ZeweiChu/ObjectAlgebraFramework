package noa.demo.alg;

public interface IPrint {
	String print();
}
