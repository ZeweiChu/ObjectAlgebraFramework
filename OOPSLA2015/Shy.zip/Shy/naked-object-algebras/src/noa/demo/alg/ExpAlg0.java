package noa.demo.alg;

public interface ExpAlg0<E> extends ExpAlg<E, E> {

}
