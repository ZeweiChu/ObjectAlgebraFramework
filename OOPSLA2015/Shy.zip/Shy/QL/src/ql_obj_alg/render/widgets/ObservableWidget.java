package ql_obj_alg.render.widgets;

import java.util.Observable;

public class ObservableWidget extends Observable {

	public void setChanged(){
		super.setChanged();
	}
}
