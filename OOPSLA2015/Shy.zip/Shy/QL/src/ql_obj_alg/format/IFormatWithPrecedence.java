package ql_obj_alg.format;

import ql_obj_alg.box.IFormat;

public interface IFormatWithPrecedence extends IFormat,IPrecedence{

}
