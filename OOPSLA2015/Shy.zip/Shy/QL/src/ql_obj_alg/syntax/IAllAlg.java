package ql_obj_alg.syntax;

public interface IAllAlg<E, S, F> extends IExpAlg<E>, IFormAlg<E, S, F>, IStmtAlg<E, S> {

}
