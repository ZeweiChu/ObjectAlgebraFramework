package ql_obj_alg.check.warnings;

public class Warning {
	
	public String toString(){
		return "Unknown warning";
	}
}
