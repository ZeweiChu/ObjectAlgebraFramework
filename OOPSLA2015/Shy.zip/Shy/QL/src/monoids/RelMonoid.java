package monoids;

import java.util.Set;

import library.Monoid;
import library.Pair;

public class RelMonoid<A> implements Monoid<Set<Pair<A,A>>> {

	@Override
	public Set<Pair<A, A>> join(Set<Pair<A, A>> x, Set<Pair<A, A>> y) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Pair<A, A>> empty() {
		// TODO Auto-generated method stub
		return null;
	}


}
