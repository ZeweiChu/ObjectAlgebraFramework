Programming language: Java 8
Development Environment: Eclipse

**********************************
Folder: Library
**********************************

This project defines and implements a Java annotation "@Algebra" which can generate generic boilerplate code automatically for data structures. When "@Algebra" is added to the definition of an Object Algebra Interface, some additional classes are then created automatically, including generic traversal code for queries, generalized queries, transformations, contextual transformations, and so on.

Moreover, two simple classes, Monoid and Pair, are also defined in this project. They are used for queries and combinators with Object Algebras, respectively.

Usage: Please import this project to Eclipse to see how it works to generate code automatically, using Java reflection with annotations. Then export it into a JAR file.

Steps:
1. Java compiler: Java 8 required;
2. In Eclipse, Properties -> Java Build Path -> Libraries, add the exported file "Library.jar" as a library;
3. In Eclipse, Properties -> Java Compiler -> Annotation Processing, select "Enable project specific settings", "Enable annotation processing", "Enable processing in editor", and set the "Generated source directory", usually it should be "src";
4. In Eclipse, Properties -> Java Compiler -> Annotation Processing -> Factory Path, add "Library.jar" as a library. If you click "Advanced..." and can see "com.zewei.annotation.processor.AlgebraProcessor", you are done with it.

**********************************
Folder: ObjectAlgebras
**********************************

This project contains the source code of our research on object algebras with annotations. You can find the examples discussed in the paper related to Object Algebras here.

**********************************
Folder: QL
**********************************

This project contains the source code of our case study on QL questionnaire together with the results. You can find the examples discussed in section "Case Study" of our paper here.

**********************************
Folder: naked-object-algebras
**********************************

Object Algebras decorated with concrete syntax annotations. ANTLR4 parser is generated automatically. Acknowledgements: Maria Gouseti, Chiel Peters. See "Readme.md".
