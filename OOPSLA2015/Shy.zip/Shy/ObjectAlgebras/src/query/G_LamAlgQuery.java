package query;

import library.Monoid;
import trees.LamAlg;

public interface G_LamAlgQuery<A0> extends LamAlg<A0> {

	Monoid<A0> mExp();

	@Override
	default A0 Apply(A0 p0, A0 p1) {
		A0 res = mExp().empty();
		res = mExp().join(res, p0);
		res = mExp().join(res, p1);
		return res;
	}

	@Override
	default A0 Lam(java.lang.String p0, A0 p1) {
		A0 res = mExp().empty();
		res = mExp().join(res, p1);
		return res;
	}

}