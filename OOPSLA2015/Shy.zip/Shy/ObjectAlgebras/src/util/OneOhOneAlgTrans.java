package util;

import transform.OneOhOneAlgTransform;
import trees.OneOhOneAlg;

public class OneOhOneAlgTrans<A0, A1, A2, A3, A4, A5> implements OneOhOneAlgTransform<A0, A1, A2, A3, A4, A5> {

	private OneOhOneAlg<A0, A1, A2, A3, A4, A5> alg;

	public OneOhOneAlgTrans(OneOhOneAlg<A0, A1, A2, A3, A4, A5> alg) {this.alg = alg;}

	public OneOhOneAlg<A0, A1, A2, A3, A4, A5> oneOhOneAlg() {return alg;}

}