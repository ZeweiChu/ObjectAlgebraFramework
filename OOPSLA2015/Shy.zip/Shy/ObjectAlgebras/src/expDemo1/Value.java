package expDemo1;

import java.util.List;

public interface Value {
	Integer getInt();
	List<String> getStringList();
}
