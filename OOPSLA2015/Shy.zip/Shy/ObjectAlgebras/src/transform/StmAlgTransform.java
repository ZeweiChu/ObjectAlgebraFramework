package transform;

import trees.StmAlg;

public interface StmAlgTransform<A0, A1, A2> extends StmAlg<A0, A1, A2> {

	StmAlg<A0, A1, A2> stmAlg();

	@Override
	default A1 EAdd(A1 p0, A1 p1) {
		return stmAlg().EAdd(p0, p1);
	}

	@Override
	default A1 EInt(int p0) {
		return stmAlg().EInt(p0);
	}

	@Override
	default A1 EStm(A0 p0) {
		return stmAlg().EStm(p0);
	}

	@Override
	default A1 EVar(java.lang.String p0) {
		return stmAlg().EVar(p0);
	}

	@Override
	default A0 SAss(java.lang.String p0, A1 p1) {
		return stmAlg().SAss(p0, p1);
	}

	@Override
	default A0 SBlock(java.util.List<A0> p0) {
		return stmAlg().SBlock(p0);
	}

	@Override
	default A0 SDecl(A2 p0, java.lang.String p1) {
		return stmAlg().SDecl(p0, p1);
	}

	@Override
	default A0 SReturn(A1 p0) {
		return stmAlg().SReturn(p0);
	}

	@Override
	default A2 TFloat() {
		return stmAlg().TFloat();
	}

	@Override
	default A2 TInt() {
		return stmAlg().TInt();
	}

}