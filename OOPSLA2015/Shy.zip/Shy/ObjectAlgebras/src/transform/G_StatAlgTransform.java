package transform;

import java.util.function.Function;
import java.util.List;
import java.util.ArrayList;
import trees.StatAlg;

public interface G_StatAlgTransform<A, B0, B1> extends StatAlg<Function<A, B0>, Function<A, B1>> {

	StatAlg<B0, B1> statAlg();

	default <B> List<B> substListStatAlg(List<Function<A, B>> list, A acc) {
		List<B> res = new ArrayList<B>();
		for (Function<A, B> i : list)
			res.add(i.apply(acc));
		return res;
	}

	@Override
	default Function<A, B1> Assign(java.lang.String p0, Function<A, B0> p1) {
		return acc -> statAlg().Assign(p0, p1.apply(acc));
	}

	@Override
	default Function<A, B1> Seq(Function<A, B1> p0, Function<A, B1> p1) {
		return acc -> statAlg().Seq(p0.apply(acc), p1.apply(acc));
	}

}