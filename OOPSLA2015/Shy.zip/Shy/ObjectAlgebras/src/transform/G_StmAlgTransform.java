package transform;

import java.util.function.Function;
import java.util.List;
import java.util.ArrayList;
import trees.StmAlg;

public interface G_StmAlgTransform<A, B0, B1, B2> extends StmAlg<Function<A, B0>, Function<A, B1>, Function<A, B2>> {

	StmAlg<B0, B1, B2> stmAlg();

	default <B> List<B> substListStmAlg(List<Function<A, B>> list, A acc) {
		List<B> res = new ArrayList<B>();
		for (Function<A, B> i : list)
			res.add(i.apply(acc));
		return res;
	}

	@Override
	default Function<A, B1> EAdd(Function<A, B1> p0, Function<A, B1> p1) {
		return acc -> stmAlg().EAdd(p0.apply(acc), p1.apply(acc));
	}

	@Override
	default Function<A, B1> EInt(int p0) {
		return acc -> stmAlg().EInt(p0);
	}

	@Override
	default Function<A, B1> EStm(Function<A, B0> p0) {
		return acc -> stmAlg().EStm(p0.apply(acc));
	}

	@Override
	default Function<A, B1> EVar(java.lang.String p0) {
		return acc -> stmAlg().EVar(p0);
	}

	@Override
	default Function<A, B0> SAss(java.lang.String p0, Function<A, B1> p1) {
		return acc -> stmAlg().SAss(p0, p1.apply(acc));
	}

	@Override
	default Function<A, B0> SBlock(List<Function<A, B0>> p0) {
		return acc -> stmAlg().SBlock(substListStmAlg(p0, acc));
	}

	@Override
	default Function<A, B0> SDecl(Function<A, B2> p0, java.lang.String p1) {
		return acc -> stmAlg().SDecl(p0.apply(acc), p1);
	}

	@Override
	default Function<A, B0> SReturn(Function<A, B1> p0) {
		return acc -> stmAlg().SReturn(p0.apply(acc));
	}

	@Override
	default Function<A, B2> TFloat() {
		return acc -> stmAlg().TFloat();
	}

	@Override
	default Function<A, B2> TInt() {
		return acc -> stmAlg().TInt();
	}

}