package ql_obj_alg.check;

public class CollectTypeEnv implements FormCollectQuestionTypes, StmtCollectQuestionTypes<Object> {

}
