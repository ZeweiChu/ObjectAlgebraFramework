Programming language: Java
Development Environment: Eclipse
Compiler: JRE 1.8

**********************************
Folder: Library
**********************************

This project defines and implements a Java annotation "@Algebra" which can generate generic boilerplate code automatically for data structures. When "@Algebra" is added to the definition of an Object Algebra Interface, some additional classes are then created automatically, including generic traversal code for queries, generalized queries, transformations, contextual transformations, and so on.

Moreover, two simple classes, Monoid and Pair, are also defined in this project. They are used for queries and combinators with Object Algebras, respectively.

Usage: Please import this project to Eclipse to see how it works to generate code automatically, using Java reflection with annotations. Then export it into a JAR file. You can also use the JAR file "Library.jar" under the Shy directory.

**********************************
Folder: Sample
**********************************

This project gives a sample using the library "Library.jar". So if you want to use the annotation "@Algebra", please add "Library.jar" to the project you are working on as a library.

Notes:
1. Java compiler: (minimum requirement) JRE 1.8;
2. In Eclipse, Properties -> Java Build Path -> Libraries, add "Library.jar" as a library.
3. In Eclipse, Properties -> Java Compiler -> Annotation Processing, select "Enable project specific settings", "Enable annotation processing", "Enable processing in editor", and set the "Generated source directory", usually it should be "src";
4. In Eclipse, Properties -> Java Compiler -> Annotation Processing -> Factory Path, add "Library.jar" as a library. If you click "Advanced..." and can see "com.zewei.annotation.processor.AlgebraProcessor", you are done with it.

This project gives interface ExpAlg as an example, for the expression Object Algebra Interface. Just like the code in ExpAlg.java, you can add the annotation "@Algebra" to a custom interface.

**********************************
Folder: ObjectAlgebras
**********************************

This project contains the source code of our research on object algebras with annotations. You can find the examples discussed in the paper related to Object Algebras here.

**********************************
Folder: QL
**********************************

This project contains the source code of our case study on QL questionnaire together with the results. You can find the examples discussed in section "Case Study" of our paper here.
