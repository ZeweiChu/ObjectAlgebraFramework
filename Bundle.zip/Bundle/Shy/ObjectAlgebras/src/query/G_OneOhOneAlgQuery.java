package query;

import library.Monoid;
import trees.OneOhOneAlg;

public interface G_OneOhOneAlgQuery<A0, A1, A2, A3, A4, A5> extends OneOhOneAlg<A0, A1, A2, A3, A4, A5> {

	Monoid<A0> mCompany();
	Monoid<A1> mDept();
	Monoid<A2> mUnit();
	Monoid<A3> mEmployee();
	Monoid<A4> mPerson();
	Monoid<A5> mSalary();

	@Override
	default A0 C(java.util.List<A1> p0) {
		A0 res = mCompany().empty();
		return res;
	}

	@Override
	default A1 D(java.lang.String p0, A3 p1, java.util.List<A2> p2) {
		A1 res = mDept().empty();
		return res;
	}

	@Override
	default A2 DU(A1 p0) {
		A2 res = mUnit().empty();
		return res;
	}

	@Override
	default A3 E(A4 p0, A5 p1) {
		A3 res = mEmployee().empty();
		return res;
	}

	@Override
	default A4 P(java.lang.String p0, java.lang.String p1) {
		A4 res = mPerson().empty();
		return res;
	}

	@Override
	default A2 PU(A3 p0) {
		A2 res = mUnit().empty();
		return res;
	}

	@Override
	default A5 S(float p0) {
		A5 res = mSalary().empty();
		return res;
	}

}