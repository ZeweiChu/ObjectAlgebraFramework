package query;

import library.Monoid;
import trees.StatAlg;

public interface G_StatAlgQuery<A0, A1> extends StatAlg<A0, A1> {

	Monoid<A0> mExp();
	Monoid<A1> mStat();

	@Override
	default A1 Assign(java.lang.String p0, A0 p1) {
		A1 res = mStat().empty();
		return res;
	}

	@Override
	default A1 Seq(A1 p0, A1 p1) {
		A1 res = mStat().empty();
		res = mStat().join(res, p0);
		res = mStat().join(res, p1);
		return res;
	}

}